#!/bin/bash -l

touch $(realpath $1)
